<footer class="site-footer">
            Footer
        </footer>
    </div>
    <?php wp_footer(); ?>
</body>
</html>