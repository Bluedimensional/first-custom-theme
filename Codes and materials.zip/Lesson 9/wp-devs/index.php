<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WP Devs</title>
</head>
<body>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Impedit officiis possimus ex sequi quo facere perspiciatis rem ratione, in quod illum ab numquam! Aliquam in, non debitis quis aspernatur voluptatum.</p>
</body>
</html>